#include "p1.h"

int main()
{
    mumsh_loop();
    return 0;
}



